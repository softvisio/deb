--
name: Feature request
about: Suggest an idea for this project

---

# Feature Request

<!--
The text in these markdown comments is instructions that will not appear in the displayed issue.
This is a suggested template, but you don't have to follow it!
-->

## Problem

<!--
A clear and concise description of what the problem is. e.g. I'm always frustrated when [...]
-->

## Proposed Solution

<!--
A description of what you want to happen.
-->
